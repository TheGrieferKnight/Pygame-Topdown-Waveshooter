import pygame

sprites_group = pygame.sprite.Group()
bullet_sprites_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
